# Voice Changer Pro — Android MVP 0.1.0

## Included
- Kotlin + Jetpack Compose gaming-style starter screen.
- Four selectable voice preset labels.
- Runtime microphone permission request.
- Android overlay permission flow.
- Foreground service that displays a simple floating bubble.

## Open in Android Studio
1. Open this folder as an existing Gradle project.
2. Use JDK 17.
3. Install Android SDK platform 35 and a recent Android Gradle Plugin-compatible Android Studio.
4. Sync Gradle, then run on a physical Android device.

## Important status
This is a UI/overlay scaffold, **not a functioning real-time voice changer yet**.
It does not capture/process/play microphone audio and does not route processed audio into
Liên Quân Mobile, Free Fire, SIM calls, Zalo, Messenger, or Discord.

Android's normal app audio APIs do not provide a general system-wide virtual microphone.
A floating overlay can control this app but cannot replace another app's microphone input.
Microphone foreground services are subject to Android version restrictions and must be
started while the app is visible with the required permissions.

## Next engineering steps
1. Add an in-app audio loopback test using AudioRecord + AudioTrack (use headphones).
2. Implement and measure DSP presets (robot modulation first; pitch/time effects need a proper
   pitch-shifting algorithm rather than simple playback-rate changes).
3. Add drag-to-move and preset selection to the floating overlay.
4. Test device-specific latency, audio focus, permissions, and foreground-service behavior.
5. Investigate only supported game/VoIP input paths; do not claim game compatibility without
   a real device test.

## Privacy
Microphone permission should be requested only when the user explicitly starts an audio test.
Do not record or upload voice samples by default.
