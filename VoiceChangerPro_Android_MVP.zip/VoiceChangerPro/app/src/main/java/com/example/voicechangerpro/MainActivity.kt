package com.example.voicechangerpro

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.voicechangerpro.overlay.FloatingControlService

private val NeonPurple = Color(0xFF9B5CFF)
private val NeonCyan = Color(0xFF45E6F5)
private val Deep = Color(0xFF0B0B16)

class MainActivity : ComponentActivity() {
    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var selected by remember { mutableStateOf(VoicePreset.FEMALE) }
            var status by remember { mutableStateOf("Sẵn sàng") }
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = NeonPurple,
                    secondary = NeonCyan,
                    background = Deep,
                    surface = Color(0xFF17172A)
                )
            ) {
                Column(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color(0xFF17102B), Deep))
                    ).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Text("VOICE CHANGER PRO", style = MaterialTheme.typography.headlineSmall,
                        color = Color.White)
                    Text("GAMING RGB  •  MVP 0.1.0", color = NeonCyan)
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF211A39))) {
                        Column(Modifier.fillMaxWidth().padding(18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("VOICE STUDIO", color = Color.White,
                                style = MaterialTheme.typography.titleLarge)
                            Text(status, color = NeonCyan)
                        }
                    }
                    Text("CHỌN HIỆU ỨNG", color = Color.White)
                    VoicePreset.entries.forEach { preset ->
                        FilterChip(
                            selected = selected == preset,
                            onClick = { selected = preset },
                            label = { Text(preset.label) }
                        )
                    }
                    Button(
                        onClick = {
                            micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            status = "Cấp quyền micro, sau đó thử âm thanh trong ứng dụng"
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("CẤP QUYỀN MICRO") }

                    OutlinedButton(
                        onClick = {
                            if (!Settings.canDrawOverlays(this@MainActivity)) {
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:$packageName")
                                )
                                startActivity(intent)
                            } else {
                                val intent = Intent(this@MainActivity, FloatingControlService::class.java)
                                ContextCompat.startForegroundService(this@MainActivity, intent)
                                status = "Đã yêu cầu mở nút nổi"
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("BẬT NÚT NỔI") }

                    Text(
                        "Lưu ý: bản MVP chỉ dựng giao diện và nút nổi. Chưa đưa âm thanh đã xử lý vào micro của game/cuộc gọi.",
                        color = Color(0xFFB8B5C8),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}

enum class VoicePreset(val label: String) {
    FEMALE("Nam → Nữ"),
    MALE("Nữ → Nam"),
    ROBOT("Robot"),
    CHILD("Giọng trẻ em")
}
